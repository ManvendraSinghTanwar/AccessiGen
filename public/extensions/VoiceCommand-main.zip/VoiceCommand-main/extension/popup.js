document.addEventListener("DOMContentLoaded", () => {
    const recordButton = document.getElementById("record");

    if (!recordButton) {
        console.error("❌ Button with ID 'record' not found! Check popup.html.");
        return;
    }

    console.log("✅ Button found, adding event listener.");

    recordButton.addEventListener("click", () => {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                const mediaRecorder = new MediaRecorder(stream);
                let audioChunks = [];

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstop = async () => {
                    const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
                    await sendAudioToAPI(audioBlob);
                };

                mediaRecorder.start();
                setTimeout(() => mediaRecorder.stop(), 3000); // Record for 3 seconds
            })
            .catch(error => console.error("❌ Error accessing microphone:", error));
    });

    // Removed the event listener for the Stop button:
    // const stopButton = document.getElementById("stop");
    // if (stopButton) { ... }
});

// ✅ Function to Send Audio to API
async function sendAudioToAPI(blob) {
    let formData = new FormData();
    formData.append("file", blob, "command.wav");

    try {
        const response = await fetch("http://127.0.0.1:8000/api/voice-command", {
            method: "POST",
            body: formData
        });

        const data = await response.json();
        console.log("🔍 Full API Response:", data);  // <-- ADD THIS LINE

        if (data.action) {
            executeCommand(data.action, data.text);
        } else {
            console.log("❌ No valid action found in the response.");
        }
    } catch (error) {
        console.error("⚠️ Error sending audio to API:", error);
    }
}

// ✅ Function to Execute Commands
function executeCommand(command, text) {
    console.log("🚀 Received command:", command);  // <-- ADD THIS LINE

    if (command === "open_url|https://www.youtube.com") {
        console.log("🌐 Sending message to background script to open YouTube...");
        chrome.runtime.sendMessage({ action: "open_youtube" }, (response) => {
            console.log("🔄 Background response:", response);
        });
    } else if (command === "open_url|https://mail.google.com") {
        console.log("📧 Sending message to background script to open Gmail...");
        chrome.runtime.sendMessage({ action: "open_gmail" }, (response) => {
            console.log("🔄 Background response:", response);
        });
    } else if (command.startsWith("search_google|")) {
        const query = command.split("|")[1];
        console.log(`🔍 Sending message to background script to search Google for: ${query}`);
        chrome.runtime.sendMessage({ action: "search_google", query: query }, (response) => {
            console.log("🔄 Background response:", response);
        });
    } else if (command === "scroll|down") {
        console.log("🚀 Sending message to background script to scroll down");
        chrome.runtime.sendMessage({ action: "scroll_down" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|down|200") {
        console.log("🚀 Sending message to background script to scroll down a little");
        chrome.runtime.sendMessage({ action: "scroll_down_little" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|down|800") {
        console.log("🚀 Sending message to background script to scroll down more");
        chrome.runtime.sendMessage({ action: "scroll_down_more" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|bottom") {
        console.log("🚀 Sending message to background script to scroll all the way down");
        chrome.runtime.sendMessage({ action: "scroll_bottom" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|up") {
        console.log("🚀 Sending message to background script to scroll up");
        chrome.runtime.sendMessage({ action: "scroll_up" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "read_page") {
        console.log("🚀 Sending message to background script to read page aloud");
        chrome.runtime.sendMessage({ action: "read_page" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "pause_tts") {
        console.log("🚀 Sending message to background script to pause text-to-speech");
        chrome.runtime.sendMessage({ action: "pause_tts" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "summarize_page") {
        console.log("🚀 Sending message to background script to summarize page");
        chrome.runtime.sendMessage({ action: "summarize_page" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "simplify_text") {
        console.log("🚀 Sending message to background script to simplify text");
        chrome.runtime.sendMessage({ action: "simplify_text" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "tab|next") {
        console.log("🚀 Sending message to background script to switch to next tab");
        chrome.runtime.sendMessage({ action: "tab_next" }, (response) => {
            console.log("🔄 Background response:", response);
        });
    } else if (command === "tab|previous") {
        console.log("🚀 Sending message to background script to switch to previous tab");
        chrome.runtime.sendMessage({ action: "tab_previous" }, (response) => {
            console.log("🔄 Background response:", response);
        });
    } else if (command.includes("scroll up")) {
        window.scrollBy(0, -500);
    } else {
        console.log("❓ Unknown command:", command);
    }
}



