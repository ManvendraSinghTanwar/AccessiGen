chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.action === "sendAudio") {
        const audioBlob = base64ToBlob(message.audio);
        await sendAudioToAPI(audioBlob);
    }
});

function base64ToBlob(base64) {
    const byteString = atob(base64.split(',')[1]);
    const mimeString = base64.split(',')[0].split(':')[1].split(';')[0];
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], { type: mimeString });
}

async function sendAudioToAPI(blob) {
    let formData = new FormData();
    formData.append("file", blob, "command.wav");

    try {
        const response = await fetch("http://127.0.0.1:8000/api/voice-command", {
            method: "POST",
            body: formData
        });

        const data = await response.json();
        console.log("🚀 Full API Response:", data);

        if (data.action) {
            executeCommand(data.action);
        } else {
            console.log("⚠️ No valid action found in API response.");
        }
    } catch (error) {
        console.error("❌ Error sending audio to API:", error);
    }
}

function executeCommand(command) {
    console.log("🎤 Command received:", command);
    
    if (command === "open_url|https://www.youtube.com") {
        console.log("🚀 Sending message to background script to open YouTube");
        chrome.runtime.sendMessage({ action: "open_youtube" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "open_url|https://mail.google.com") {
        console.log("📧 Sending message to background script to open Gmail...");
        chrome.runtime.sendMessage({ action: "open_gmail" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command.startsWith("search_google|")) {
        const query = command.split("|")[1];
        console.log(`🔍 Sending message to background script to search Google for: ${query}`);
        chrome.runtime.sendMessage({ action: "search_google", query: query }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|down") {
        console.log("🚀 Sending message to background script to scroll down");
        chrome.runtime.sendMessage({ action: "scroll_down" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|down|200") {
        console.log("🚀 Sending message to background script to scroll down a little");
        chrome.runtime.sendMessage({ action: "scroll_down_little" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|down|800") {
        console.log("🚀 Sending message to background script to scroll down more");
        chrome.runtime.sendMessage({ action: "scroll_down_more" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|bottom") {
        console.log("🚀 Sending message to background script to scroll all the way down");
        chrome.runtime.sendMessage({ action: "scroll_bottom" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "scroll|up") {
        console.log("🚀 Sending message to background script to scroll up");
        chrome.runtime.sendMessage({ action: "scroll_up" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "read_page") {
        console.log("🚀 Sending message to background script to read page aloud");
        chrome.runtime.sendMessage({ action: "read_page" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "pause_tts") {
        console.log("🚀 Sending message to background script to pause text-to-speech");
        chrome.runtime.sendMessage({ action: "pause_tts" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "summarize_page") {
        console.log("🚀 Sending message to background script to summarize page");
        chrome.runtime.sendMessage({ action: "summarize_page" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "simplify_text") {
        console.log("🚀 Sending message to background script to simplify text");
        chrome.runtime.sendMessage({ action: "simplify_text" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "tab|next") {
        console.log("🚀 Sending message to background script to switch to next tab");
        chrome.runtime.sendMessage({ action: "tab_next" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command === "tab|previous") {
        console.log("🚀 Sending message to background script to switch to previous tab");
        chrome.runtime.sendMessage({ action: "tab_previous" }, (response) => {
            console.log("🔄 Response from background:", response);
        });
    } else if (command.includes("scroll up")) { // fallback if not exact
        window.scrollBy(0, -500);
    } else {
        console.log("⚠️ Unknown command:", command);
    }
}

