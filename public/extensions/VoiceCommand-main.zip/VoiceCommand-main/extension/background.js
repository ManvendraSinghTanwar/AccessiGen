chrome.runtime.onInstalled.addListener(() => {
 console.log("🔧 Extension installed or updated.");
 // Perform any setup tasks here
});

// ✅ Listen for messages from content scripts or popup.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
 console.log("📩 Message received in background.js:", message);

 if (message.action === "open_youtube") {
     console.log("🌐 Opening YouTube...");
     chrome.tabs.create({ url: "https://www.youtube.com" }, (tab) => {
         if (chrome.runtime.lastError) {
             console.error("❌ Error:", chrome.runtime.lastError.message);
             sendResponse({ status: "error", message: chrome.runtime.lastError.message });
         } else {
             console.log("✅ YouTube opened successfully!", tab);
             sendResponse({ status: "success" });
         }
     });

     return true; // Keeps sendResponse() alive for async callback
 }

 if (message.action === "open_gmail") {
     console.log("📧 Opening Gmail...");
     chrome.tabs.create({ url: "https://mail.google.com" }, (tab) => {
         if (chrome.runtime.lastError) {
             console.error("❌ Error:", chrome.runtime.lastError.message);
             sendResponse({ status: "error", message: chrome.runtime.lastError.message });
         } else {
             console.log("✅ Gmail opened successfully!", tab);
             sendResponse({ status: "success" });
         }
     });

     return true; // Keeps sendResponse() alive for async callback
 }

 if (message.action === "search_google") {
     const query = message.query || "";
     console.log(`🔍 Searching Google for: ${query}`);
     chrome.tabs.create({ url: `https://www.google.com/search?q=${encodeURIComponent(query)}` }, (tab) => {
         if (chrome.runtime.lastError) {
             console.error("❌ Error:", chrome.runtime.lastError.message);
             sendResponse({ status: "error", message: chrome.runtime.lastError.message });
         } else {
             console.log("✅ Google search opened successfully!", tab);
             sendResponse({ status: "success" });
         }
     });

     return true; // Keeps sendResponse() alive for async callback
 }

 if (message.action === "scroll_down") {
     console.log("🔧 Executing scroll down via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => window.scrollBy(0, 500)
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "scroll_down_little") {
     console.log("🔧 Executing scroll down a little via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => window.scrollBy(0, 200)
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "scroll_down_more") {
     console.log("🔧 Executing scroll down more via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => window.scrollBy(0, 800)
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "scroll_bottom") {
     console.log("🔧 Executing scroll all the way down via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => window.scrollTo(0, document.body.scrollHeight)
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "scroll_up") {
     console.log("🔧 Executing scroll up via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => window.scrollBy(0, -500)
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "read_page") {
  console.log("🔧 Executing read page via background script...");

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: () => document.body.innerText || "No content available to read."
      }, (results) => {
          if (chrome.runtime.lastError) {
              console.error("Script execution error:", chrome.runtime.lastError);
              return;
          }

          if (results && results[0] && results[0].result) {
              const text = results[0].result;
              const maxLength = 2000; // Limit per chunk
              const chunks = [];

              for (let i = 0; i < text.length; i += maxLength) {
                  chunks.push(text.substring(i, i + maxLength));
              }

              function speakChunks(index) {
                  if (index < chunks.length) {
                      chrome.tts.speak(chunks[index], { rate: 1.0 }, () => {
                          speakChunks(index + 1); // Speak the next chunk
                      });
                  } else {
                      console.log("🔊 Finished reading.");
                  }
              }

              speakChunks(0);
          } else {
              console.warn("❌ No readable text found.");
          }
      });
  });

  return true; // Keep message channel open for async response
}


 if (message.action === "pause_tts") {
     console.log("🔧 Pausing text-to-speech via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => {
                 speechSynthesis.pause();
             }
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 if (message.action === "summarize_page") {
     console.log("🔧 Summarizing page via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => document.body.innerText
         }, (results) => {
             if (results && results[0] && results[0].result) {
                 const text = results[0].result;
                 fetch("http://127.0.0.1:8000/api/summarize", {
                     method: "POST",
                     headers: {
                         "Content-Type": "application/json"
                     },
                     body: JSON.stringify({ text: text })
                 })
                 .then(response => response.json())
                 .then(data => {
                     const summary = data.summary;
                     const utterance = new SpeechSynthesisUtterance(summary);
                     speechSynthesis.speak(utterance);
                     sendResponse({ status: "success", summary: summary });
                 })
                 .catch(error => {
                     console.error("❌ Error summarizing text:", error);
                     sendResponse({ status: "error", message: error.message });
                 });
             } else {
                 sendResponse({ status: "error", message: "No text found to summarize" });
             }
         });
     });
     return true;
 }

 if (message.action === "simplify_text") {
     console.log("🔧 Simplifying text via background script...");
     chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
         chrome.scripting.executeScript({
             target: { tabId: tabs[0].id },
             function: () => {
                 const text = document.body.innerText || "No content available to simplify.";
                 // Placeholder for simplification logic
                 const simplifiedText = text.split('.').slice(0, 3).join('.') + '.';
                 const utterance = new SpeechSynthesisUtterance(simplifiedText);
                 speechSynthesis.speak(utterance);
             }
         }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }

 // NEW branch for "next tab"
 if (message.action === "tab_next") {
     console.log("🔧 Switching to next tab...");
     chrome.tabs.query({ currentWindow: true }, (tabs) => {
         let activeIndex = tabs.findIndex(tab => tab.active);
         let nextIndex = (activeIndex + 1) % tabs.length;
         chrome.tabs.update(tabs[nextIndex].id, { active: true }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }
 
 // NEW branch for "previous tab"
 if (message.action === "tab_previous") {
     console.log("🔧 Switching to previous tab...");
     chrome.tabs.query({ currentWindow: true }, (tabs) => {
         let activeIndex = tabs.findIndex(tab => tab.active);
         let prevIndex = activeIndex - 1;
         if (prevIndex < 0) {
             prevIndex = tabs.length - 1;
         }
         chrome.tabs.update(tabs[prevIndex].id, { active: true }, () => {
             sendResponse({ status: "success" });
         });
     });
     return true;
 }
});
