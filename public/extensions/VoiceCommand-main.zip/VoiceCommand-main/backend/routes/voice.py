from fastapi import APIRouter, HTTPException, Request
from transformers import pipeline, AutoTokenizer
import speech_recognition as sr
from fuzzywuzzy import process
import pyttsx3  # For text-to-speech

router = APIRouter()

# Load the BERT-based NLP model for command recognition
try:
    command_model = pipeline("text-classification", model="bert-base-uncased")
except Exception as e:
    raise RuntimeError(f"Failed to load NLP model: {e}")

# Load the T5/BART model for text summarization
try:
    summarization_model = pipeline("summarization", model="facebook/bart-large-cnn")
    summarization_tokenizer = AutoTokenizer.from_pretrained("facebook/bart-large-cnn")
except Exception as e:
    raise RuntimeError(f"Failed to load summarization model: {e}")

# Text-to-Speech Engine
tts_engine = pyttsx3.init()

# Command mappings
COMMANDS_MAP = {
    "go to youtube": "open_url|https://www.youtube.com",
    "scroll down": "scroll|down",
    "scroll up": "scroll|up",
    "scroll down a little": "scroll|down|200",
    "scroll down more": "scroll|down|800",
    "scroll all the way down": "scroll|bottom",
    "read": "read_page",   # <-- Now "read" maps to "read_page"
    "pause reading": "pause_tts",
    "summarize this page": "summarize_page",
    "explain this in simple terms": "simplify_text",
    "next tab": "tab|next",
    "previous tab": "tab|previous",
    "open Gmail": "open_url|https://mail.google.com",
    "search for": "search_google",
}

def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening for command...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        audio = recognizer.listen(source)
    
    try:
        text = recognizer.recognize_google(audio, language="en-US").lower()
        print(f"Recognized: {text}")
        return text
    except sr.UnknownValueError:
        return None
    except sr.RequestError:
        raise HTTPException(status_code=500, detail="Speech recognition API error")

def get_best_match(command_text):
    best_match, score = process.extractOne(command_text, COMMANDS_MAP.keys())
    return best_match if score > 70 else None

def speak(text):
    """ Convert text to speech for accessibility. """
    tts_engine.say(text)
    tts_engine.runAndWait()

def truncate_text(text, max_tokens=1024):
    """ Truncate text properly based on tokenizer limits """
    tokens = summarization_tokenizer.encode(text, truncation=True, max_length=max_tokens)
    return summarization_tokenizer.decode(tokens, skip_special_tokens=True)

@router.post("/voice-command")
async def process_voice_command():
    command_text = recognize_speech()
    
    if not command_text:
        raise HTTPException(status_code=400, detail="Could not understand the command")

    # Classify the command
    prediction = command_model(command_text)
    intent = prediction[0]["label"].lower()
    
    best_match = get_best_match(command_text)
    if best_match:
        action = COMMANDS_MAP[best_match]
        if action == "read_page":
            return {"action": action, "text": command_text}
        return {"action": action}

    return {"message": "Command not recognized"}

@router.post("/summarize")
async def summarize_text(request: Request):
    """ API to summarize text using T5/BART model """
    data = await request.json()
    text = data.get("text", "").strip()

    if not text:
        raise HTTPException(status_code=400, detail="No text provided for summarization")

    # Ensure text is within model limits
    truncated_text = truncate_text(text)

    try:
        summary = summarization_model(truncated_text, max_length=150, min_length=40, do_sample=False)
        return {"summary": summary[0]['summary_text']}
    except IndexError:
        raise HTTPException(status_code=500, detail="Summarization model encountered an indexing error")

@router.get("/speak")
async def text_to_speech(text: str):
    """ API to convert text to speech """
    speak(text)
    return {"status": "success", "message": "Speaking text"}
