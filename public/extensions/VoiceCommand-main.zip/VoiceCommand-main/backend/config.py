import os
import pandas as pd
import torchaudio
from pydub import AudioSegment
from tqdm import tqdm

DATASET_PATH = "backend/models/speech_model/dataset/common_voice"
OUTPUT_PATH = "backend/models/speech_model/dataset/processed"

os.makedirs(OUTPUT_PATH, exist_ok=True)

# Convert MP3 to WAV (16kHz)
def convert_audio(file_path, output_path):
    audio = AudioSegment.from_file(file_path, format="mp3")
    audio = audio.set_channels(1).set_frame_rate(16000)
    audio.export(output_path, format="wav")

# Process dataset TSV
def process_dataset(split="train"):
    df = pd.read_csv(f"{DATASET_PATH}/{split}.tsv", sep="\t")
    processed_data = []
    
    for _, row in tqdm(df.iterrows(), total=len(df)):
        audio_path = os.path.join(DATASET_PATH, "clips", row["path"])
        output_audio_path = os.path.join(OUTPUT_PATH, row["path"].replace(".mp3", ".wav"))
        
        convert_audio(audio_path, output_audio_path)
        processed_data.append([output_audio_path, row["sentence"]])
    
    pd.DataFrame(processed_data, columns=["audio_path", "text"]).to_csv(f"{OUTPUT_PATH}/{split}.csv", index=False)

# Run preprocessing
process_dataset("train")
process_dataset("dev")
process_dataset("test")

print("✅ Dataset preprocessing complete!")
