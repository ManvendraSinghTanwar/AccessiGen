from fastapi import FastAPI
from routes.voice import router as voice_router

app = FastAPI()

app.include_router(voice_router, prefix="/api")

@app.get("/")
def root():
    return {"message": "AccessiGen Voice Control API is running!"}
