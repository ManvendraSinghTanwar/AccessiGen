from flask import Flask, request, jsonify
from flask_cors import CORS
from transformers import BlipProcessor, BlipForConditionalGeneration, T5Tokenizer, T5ForConditionalGeneration
from PIL import Image
import requests
import torch

app = Flask(__name__)
CORS(app)  # ✅ Enables CORS

# Load BLIP model
processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-large")
model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-large")
# ✅ Load T5 model (for text simplification)
t5_tokenizer = T5Tokenizer.from_pretrained("t5-small")
t5_model = T5ForConditionalGeneration.from_pretrained("t5-small")

@app.route("/generate-caption", methods=["POST"])
def generate_caption():
    data = request.json
    image_url = data.get("url")

    try:
        response = requests.get(image_url, stream=True)
        image = Image.open(response.raw).convert("RGB")

        inputs = processor(images=image, return_tensors="pt")
        caption_ids = model.generate(**inputs)
        caption = processor.batch_decode(caption_ids, skip_special_tokens=True)[0]

        return jsonify({"caption": caption})

    except Exception as e:
        return jsonify({"error": str(e)})

@app.route("/simplify-text", methods=["POST"])
def simplify_text():
    """Simplify complex text using the T5 model."""
    data = request.json
    complex_text = data.get("text", "")

    if not complex_text:
        return jsonify({"error": "No text provided"}), 400

    try:
        # Prepare input for T5 model
        input_text = "simplify: " + complex_text
        inputs = t5_tokenizer(input_text, return_tensors="pt")
        
        # Generate simplified text
        outputs = t5_model.generate(**inputs)
        simplified_text = t5_tokenizer.decode(outputs[0], skip_special_tokens=True)

        return jsonify({"simplified_text": simplified_text})

    except Exception as e:
        return jsonify({"error": str(e)})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
