function sendMessage(action) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, { action });
    });
}

// Button Click Events
document.getElementById("captionBtn").addEventListener("click", () => sendMessage("addImageCaptions"));
document.getElementById("simplifyBtn").addEventListener("click", () => sendMessage("simplifyPageText"));
document.getElementById("ttsBtn").addEventListener("click", () => sendMessage("readTextAloud"));
document.getElementById("playBtn").addEventListener("click", () => sendMessage("readTextAloud"));
document.getElementById("pauseBtn").addEventListener("click", () => sendMessage("pauseReading"));
document.getElementById("resumeBtn").addEventListener("click", () => sendMessage("resumeReading"));
document.getElementById("stopBtn").addEventListener("click", () => sendMessage("stopReading"));
document.getElementById("restartBtn").addEventListener("click", () => sendMessage("restartReading"));

// Dark Mode Toggle
document.getElementById("darkModeToggle").addEventListener("change", function () {
    sendMessage("toggleDarkMode");
});

// High Contrast Mode Toggle
document.getElementById("contrastToggle").addEventListener("change", function () {
    sendMessage("toggleHighContrast");
});

// Low Contrast Mode Toggle
document.getElementById("lowContrastToggle").addEventListener("change", function () {
    sendMessage("toggleLowContrast");
});

// Grayscale Mode Toggle
document.getElementById("grayscaleToggle").addEventListener("change", function () {
    sendMessage("toggleGrayscale");
});

// Dyslexia-Friendly Font Toggle
document.getElementById("dyslexiaToggle").addEventListener("change", function () {
    sendMessage("toggleDyslexiaFont");
});

// Pause Animations Toggle
document.getElementById("pauseAnimationsToggle").addEventListener("change", function () {
    sendMessage("pauseAnimations");
});

// Text Size Adjustments
document.getElementById("increaseText").addEventListener("click", () => sendMessage("increaseFontSize"));
document.getElementById("decreaseText").addEventListener("click", () => sendMessage("decreaseFontSize"));
