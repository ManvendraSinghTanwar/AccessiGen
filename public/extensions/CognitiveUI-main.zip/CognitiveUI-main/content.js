async function addImageCaptions() {
    const images = document.querySelectorAll("img");
    for (let img of images) {
        if (!img.alt || img.alt.trim() === "") {
            try {
                const caption = await generateAltText(img.src);
                const captionElement = document.createElement("div");
                captionElement.textContent = caption;
                Object.assign(captionElement.style, {
                    fontSize: "14px",
                    color: "yellow",
                    backgroundColor: "rgba(0, 0, 0, 0.8)",
                    padding: "10px",
                    borderRadius: "5px",
                    marginTop: "5px",
                    maxWidth: "80%",
                    textAlign: "center",
                    position: "relative",
                    zIndex: "1000"
                });
                img.parentNode.insertBefore(captionElement, img.nextSibling);
            } catch (error) {
                console.error("Error generating caption:", error);
            }
        }
    }
}

async function generateAltText(imageUrl) {
    try {
        const response = await fetch("http://127.0.0.1:5000/generate-caption", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: imageUrl }),
        });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        return data.caption || "Caption generation failed";
    } catch (error) {
        console.error("Fetch error:", error);
        return "Error generating caption";
    }
}

async function simplifyText(text) {
    try {
        const response = await fetch("http://127.0.0.1:5000/simplify-text", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text }),
        });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        return data.simplified_text || "Simplification failed";
    } catch (error) {
        console.error("Fetch error:", error);
        return "Error simplifying text";
    }
}

async function simplifyPageText() {
    const paragraphs = document.querySelectorAll("p");
    for (let p of paragraphs) {
        if (p.innerText.length > 50) {
            try {
                p.innerText = await simplifyText(p.innerText);
            } catch (error) {
                console.error("Error simplifying text:", error);
            }
        }
    }
}

// Accessibility Features
// Store initial styles
const initialBackgroundColor = document.body.style.background;
const initialTextColor = document.body.style.color;

function toggleDarkMode() {
    let isDarkMode = document.body.classList.toggle("dark-mode");

    if (isDarkMode) {
        document.body.style.backgroundColor = "#000000";
        document.body.style.color = "#FFD700"; // Gold text for readability
        document.querySelectorAll("a").forEach(link => link.style.color = "#00BFFF"); // Deep sky blue links
        localStorage.setItem("darkMode", "enabled");
    } else {
        document.body.style.backgroundColor = "";
        document.body.style.color = "";
        document.querySelectorAll("a").forEach(link => link.style.color = "");
        localStorage.setItem("darkMode", "disabled");
    }
}

// Apply dark mode on page load if enabled
if (localStorage.getItem("darkMode") === "enabled") {
    toggleDarkMode();
}


function toggleHighContrast() {
    document.body.classList.toggle("high-contrast");
    document.body.style.filter = document.body.classList.contains("high-contrast") ? "contrast(200%)" : "";
}

function toggleLowContrast() {
    document.body.classList.toggle("low-contrast");
    document.body.style.filter = document.body.classList.contains("low-contrast") ? "contrast(25%)" : "";
}

function toggleGrayscale() {
    document.body.classList.toggle("grayscale");
    document.body.style.filter = document.body.classList.contains("grayscale") ? "grayscale(50%)" : "";
}

function toggleDyslexiaFont() {
    document.body.classList.toggle("dyslexia-font");
    document.body.style.fontFamily = document.body.classList.contains("dyslexia-font") ? "'OpenDyslexic', Arial, sans-serif" : "";
}

function pauseAnimations() {
    document.body.classList.toggle("pause-animations");
    const css = document.body.classList.contains("pause-animations") 
        ? "* { animation: none !important; transition: none !important; }" 
        : "";
    applyStyle(css);
}

function applyStyle(css) {
    let styleTag = document.getElementById("customStyle");
    if (!styleTag) {
        styleTag = document.createElement("style");
        styleTag.id = "customStyle";
        document.head.appendChild(styleTag);
    }
    styleTag.innerHTML = css;
}

// Text-to-Speech (TTS)
let speech = new SpeechSynthesisUtterance();
let isPaused = false;

function readTextAloud() {
    let selectedText = window.getSelection().toString();
    if (!selectedText) {
        selectedText = document.body.innerText; // Read entire page if no selection
    }

    speech.text = selectedText;
    speech.rate = 1; // Normal speed
    speech.pitch = 1;
    speech.lang = "en-US"; // Adjust as needed
    isPaused = false;
    speechSynthesis.speak(speech);
}

function pauseReading() {
    if (speechSynthesis.speaking) {
        speechSynthesis.pause();
        isPaused = true;
    }
}

function resumeReading() {
    if (isPaused) {
        speechSynthesis.resume();
        isPaused = false;
    }
}

function stopReading() {
    speechSynthesis.cancel();
    isPaused = false;
}

function restartReading() {
    stopReading();
    readTextAloud();
}


// Font Size Adjustments
function adjustFontSize(increase = true) {
    document.querySelectorAll("p, h1, h2, h3, h4, h5, h6, li, a, span").forEach(el => {
        const currentSize = parseFloat(window.getComputedStyle(el).fontSize);
        el.style.fontSize = `${increase ? currentSize + 2 : currentSize - 2}px`;
    });
}

function increaseFontSize() {
    adjustFontSize(true);
}

function decreaseFontSize() {
    adjustFontSize(false);
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action) {
        switch (message.action) {
            case "addImageCaptions":
                addImageCaptions();
                break;
            case "simplifyPageText":
                simplifyPageText();
                break;
            case "readTextAloud":
                readTextAloud();
                break;
            case "pauseReading":
                pauseReading();
                break;
            case "resumeReading":
                resumeReading();
                break;
            case "stopReading":
                stopReading();
                break;
            case "restartReading":
                restartReading();
                break;
            case "toggleDarkMode":
                toggleDarkMode();
                break;
            case "toggleHighContrast":
                toggleHighContrast();
                break;
            case "toggleLowContrast":
                toggleLowContrast();
                break;
            case "toggleGrayscale":
                toggleGrayscale();
                break;
            case "toggleDyslexiaFont":
                toggleDyslexiaFont();
                break;
            case "pauseAnimations":
                pauseAnimations();
                break;
            case "increaseFontSize":
                increaseFontSize();
                break;
            case "decreaseFontSize":
                decreaseFontSize();
                break;
            default:
                console.warn("Unknown action:", message.action);
        }
    }
});

// Ensure functions are accessible globally
window.addImageCaptions = addImageCaptions;
window.simplifyPageText = simplifyPageText;
window.readTextAloud = readTextAloud;
window.pauseReading = pauseReading;
window.resumeReading = resumeReading;
window.stopReading = stopReading;
window.restartReading = restartReading;
window.increaseFontSize = increaseFontSize;
window.decreaseFontSize = decreaseFontSize;


