document.addEventListener("DOMContentLoaded", () => {
    const button = document.getElementById("start-translation");
    const status = document.getElementById("status");

    const updateStatus = (message, isError = false) => {
        status.textContent = message;
        status.style.color = isError ? 'red' : 'black';
    };

    async function injectScripts(tabId) {
        try {
            // Reset state
            await chrome.scripting.executeScript({
                target: { tabId },
                func: () => {
                    window.whisperModel?.stopRecognition?.();
                    window.whisperModel = null;
                    window.SpeechRecognizer = null;
                    window.speechRecognizerLoaded = false;
                }
            });

            // Inject speech recognition
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['libs/speech-recognition.js']
            });

            // Wait for speech recognition and verify
            const verifyInterval = 500;
            const maxAttempts = 10;
            for (let i = 0; i < maxAttempts; i++) {
                const loaded = await chrome.scripting.executeScript({
                    target: { tabId },
                    func: () => window.speechRecognizerLoaded
                });
                
                if (loaded[0].result) break;
                if (i === maxAttempts - 1) {
                    throw new Error('Speech recognition failed to load');
                }
                await new Promise(resolve => setTimeout(resolve, verifyInterval));
            }

            // Inject and initialize whisper
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['models/whisper.js']
            });

            // Wait and verify whisper model
            for (let i = 0; i < maxAttempts; i++) {
                const loaded = await chrome.scripting.executeScript({
                    target: { tabId },
                    func: () => window.whisperModel?.isLoaded
                });
                
                if (loaded[0].result) break;
                if (i === maxAttempts - 1) {
                    throw new Error('Whisper model failed to load');
                }
                await new Promise(resolve => setTimeout(resolve, verifyInterval));
            }

            // Finally inject content script
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['scripts/content.js']
            });
        } catch (error) {
            console.error('Script injection failed:', error);
            throw error;
        }
    }

    if (button) {
        button.addEventListener("click", async () => {
            try {
                updateStatus("Checking video page...");
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                
                if (tab?.id) {
                    updateStatus("Loading translation model...");
                    
                    await injectScripts(tab.id);
                    await new Promise(resolve => setTimeout(resolve, 1000));

                    chrome.tabs.sendMessage(tab.id, { action: "start_translation" }, (response) => {
                        if (chrome.runtime.lastError) {
                            updateStatus("Please refresh and try again (Error: " + chrome.runtime.lastError.message + ")", true);
                            return;
                        }
                        
                        if (response?.success) {
                            updateStatus("Translation active");
                            button.textContent = "Translation Running";
                            button.disabled = true;
                        } else {
                            updateStatus("Error: " + (response?.error || "Unknown error"), true);
                        }
                    });
                }
            } catch (error) {
                updateStatus(`Error: ${error.message}`, true);
                console.error('Extension error:', error);
            }
        });
    }
});
