(() => {
    // Only initialize once
    if (window.contentScriptInjected) return;
    window.contentScriptInjected = true;

    // Create connection only if not exists
    const port = window.contentPort || chrome.runtime.connect({ name: "content-script" });
    window.contentPort = port;

    let isTranslating = false;

    console.log("Content script loaded and ready");

    const initializeWhisper = async () => {
        try {
            let attempts = 0;
            const maxAttempts = 10; // Reduced from 20
            
            while (attempts < maxAttempts) {
                if (window.whisperModel?.isLoaded) {
                    console.log('Components initialized successfully');
                    return true;
                }
                console.log('Waiting for initialization...', attempts + 1);
                await new Promise(resolve => setTimeout(resolve, 500));
                attempts++;
            }
            throw new Error('Initialization timed out');
        } catch (error) {
            console.error('Failed to initialize:', error);
            return false;
        }
    };

    const findVideoElement = () => {
        // Try standard video element first
        let video = document.querySelector('video');
        
        // Check common video player classes/IDs
        if (!video) {
            const possibleSelectors = [
                '.html5-main-video', // YouTube
                '.vjs-tech', // VideoJS
                '.video-stream', // Common streaming
                '[data-video-id]', // Various platforms
                'video#player', // Common ID
                'video[src]', // Direct source videos
                'video source[src]' // Videos with source elements
            ];
            
            for (const selector of possibleSelectors) {
                video = document.querySelector(selector);
                if (video) break;
            }
        }
        
        // Look in iframes if no video found
        if (!video) {
            const iframes = document.querySelectorAll('iframe');
            for (const iframe of iframes) {
                try {
                    const iframeVideo = iframe.contentDocument?.querySelector('video');
                    if (iframeVideo) {
                        video = iframeVideo;
                        break;
                    }
                } catch (e) {
                    console.log('Cannot access iframe content');
                }
            }
        }
        
        return video;
    };

    const startTranslation = async () => {
        if (isTranslating) return;

        try {
            // Use persistent permission request for audio
            const result = await navigator.permissions.query({ name: 'microphone' });
            if (result.state === 'denied') {
                alert('Microphone permission is required for sign language translation. Please allow microphone access in your browser settings.');
                return { success: false, error: 'Audio permission denied' };
            }
            
            // Request audio only if not already granted
            if (result.state === 'prompt') {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ 
                        audio: true,
                        video: false
                    });
                    stream.getTracks().forEach(track => track.stop());
                } catch (error) {
                    alert('Audio permission is required for sign language translation');
                    return { success: false, error: 'Audio permission denied' };
                }
            }
        } catch (error) {
            console.error('Permission check failed:', error);
        }

        try {
            const initialized = await initializeWhisper();
            if (!initialized) {
                throw new Error('Speech recognition not ready. Please wait a moment and try again.');
            }
        } catch (error) {
            console.error('Failed to initialize:', error);
            return { success: false, error: error.message };
        }

        const video = findVideoElement();
        if (!video) {
            alert('No video found on this page! Make sure the video is playing.');
            return { success: false, error: 'No video found' };
        }

        // Ensure video is ready
        if (video.readyState < 2) { // HAVE_CURRENT_DATA
            await new Promise(resolve => {
                video.addEventListener('canplay', resolve, { once: true });
                setTimeout(resolve, 5000); // Timeout after 5 seconds
            });
        }

        try {
            if (!window.whisperModel || !window.whisperModel.transcribe) {
                const initialized = await initializeWhisper();
                if (!initialized) {
                    throw new Error('Speech recognition system not available. Please refresh and try again.');
                }
            }

            isTranslating = true;

            // Create overlay with canvas for sign language visualization
            const overlay = document.createElement('div');
            overlay.id = 'sign-language-overlay';
            
            const canvas = document.createElement('canvas');
            canvas.width = 300;
            canvas.height = 200;
            
            const textDisplay = document.createElement('div');
            textDisplay.style.cssText = `
                padding: 10px;
                margin-top: 10px;
                font-size: 14px;
                color: white;
            `;
            
            overlay.appendChild(canvas);
            overlay.appendChild(textDisplay);
            
            overlay.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 300px;
                background: rgba(0, 0, 0, 0.8);
                padding: 10px;
                z-index: 10000;
                border-radius: 10px;
                display: flex;
                flex-direction: column;
                align-items: center;
            `;
            document.body.appendChild(overlay);

            let lastProcessedTime = 0;
            const PROCESS_INTERVAL = 2000; // Process every 2 seconds

            // Update overlay styles
            overlay.style.cssText = `
                position: fixed;
                bottom: 40px;
                right: 40px;
                width: 400px;
                background: rgba(0, 0, 0, 0.9);
                padding: 20px;
                z-index: 100000;
                border-radius: 15px;
                display: flex;
                flex-direction: column;
                align-items: center;
                border: 2px solid white;
                box-shadow: 0 0 10px rgba(0,0,0,0.5);
            `;

            // Make canvas larger
            canvas.width = 380;
            canvas.height = 300;
            canvas.style.border = '1px solid #333';

            // Update text display
            textDisplay.style.cssText = `
                padding: 15px;
                margin-top: 15px;
                font-size: 16px;
                color: white;
                background: rgba(0, 0, 0, 0.7);
                border-radius: 8px;
                width: 100%;
                text-align: center;
            `;

            // Add debug info display
            const debugInfo = document.createElement('div');
            debugInfo.style.cssText = `
                position: absolute;
                top: 10px;
                left: 10px;
                color: yellow;
                font-size: 12px;
            `;
            overlay.appendChild(debugInfo);

            // Handle video transcription and sign language rendering
            video.addEventListener('timeupdate', async () => {
                if (!isTranslating || !window.whisperModel?.transcribe) return;
                
                const currentTime = video.currentTime;
                // Only process if enough time has passed
                if (currentTime - lastProcessedTime < PROCESS_INTERVAL / 1000) return;
                
                try {
                    debugInfo.textContent = `Processing at: ${currentTime.toFixed(2)}s`;
                    const result = await window.whisperModel.transcribe({
                        videoElement: video,
                        time: currentTime
                    });

                    if (result?.originalText) {
                        textDisplay.textContent = result.originalText;
                        debugInfo.textContent += ` | Text: ${result.originalText}`;
                        
                        if (result.signGestures) {
                            await window.whisperModel.renderSignLanguage(canvas, result.signGestures);
                        }
                    }
                    
                    lastProcessedTime = currentTime;
                } catch (error) {
                    console.error('Translation error:', error);
                    debugInfo.textContent += ` | Error: ${error.message}`;
                }
            });

            // Add close button
            const closeButton = document.createElement('button');
            closeButton.textContent = '×';
            closeButton.style.cssText = `
                position: absolute;
                top: 5px;
                right: 5px;
                background: none;
                border: none;
                color: white;
                font-size: 20px;
                cursor: pointer;
            `;
            closeButton.onclick = () => {
                isTranslating = false;
                if (window.whisperModel?.recognition) {
                    window.whisperModel.recognition.stop();
                }
                overlay.remove();
            };
            overlay.appendChild(closeButton);

            return { success: true };
        } catch (error) {
            isTranslating = false;
            console.error('Failed to start translation:', error);
            return { success: false, error: error.message };
        }
    };

    // Initialize message listener
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "start_translation") {
            startTranslation()
                .then((result) => {
                    console.log("Translation started:", result);
                    sendResponse({ success: true });
                })
                .catch(error => {
                    console.error("Translation error:", error);
                    sendResponse({ success: false, error: error.message });
                });
            return true;
        }
    });
})();
