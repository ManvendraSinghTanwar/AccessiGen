// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
});

chrome.action.onClicked.addListener(async (tab) => {
    if (tab.id) {
        try {
            // Load models first
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['models/whisper.js']
            });
            
            // Wait for model to initialize
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Then load content script
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['scripts/content.js']
            });
            
            console.log('Scripts injected successfully');
        } catch (err) {
            console.error('Failed to inject scripts:', err);
        }
    }
});

// Listen for content script connection
chrome.runtime.onConnect.addListener((port) => {
    if (port.name === "content-script") {
        console.log("Content script connected");
    }
});
