(() => {
    if (window.VideoSignLanguageConverter) return;

    class VideoSignLanguageConverter {
        constructor() {
            this.isLoaded = false;
            this.recognition = null;
            this.poseDetector = null;
            this.avatarModel = null;
            this.initializationPromise = null;
            this.transcriptionQueue = [];
            this.lastResult = null;
            this.gestureCache = new Map(); // Cache for generated gestures
        }

        async load() {
            if (this.isLoaded) return this;
            if (this.initializationPromise) return this.initializationPromise;

            this.initializationPromise = (async () => {
                try {
                    await this.loadPoseDetector();
                    
                    // Wait for SpeechRecognizer to be available
                    let attempts = 0;
                    while (!window.speechRecognizerLoaded && attempts < 10) {
                        await new Promise(resolve => setTimeout(resolve, 500));
                        attempts++;
                    }
                    
                    if (!window.SpeechRecognizer) {
                        throw new Error('SpeechRecognizer not available');
                    }

                    this.recognition = new window.SpeechRecognizer();
                    this.isLoaded = true;
                    console.log('Speech recognition initialized successfully');
                    return this;
                } catch (error) {
                    this.isLoaded = false;
                    this.initializationPromise = null;
                    throw error;
                }
            })();

            return this.initializationPromise;
        }

        async loadPoseDetector() {
            try {
                // Use simple pose detection without MediaPipe
                this.poseDetector = {
                    detect: async () => {
                        // Return basic pose data
                        return [{
                            keypoints: this.getBasicPoseKeypoints()
                        }];
                    }
                };
                return true;
            } catch (error) {
                console.error('Error loading pose detector:', error);
                return false;
            }
        }

        getBasicPoseKeypoints() {
            // Define basic pose keypoints
            return [
                { x: 0.5, y: 0.2, name: 'head' },
                { x: 0.5, y: 0.3, name: 'neck' },
                { x: 0.3, y: 0.3, name: 'left_shoulder' },
                { x: 0.7, y: 0.3, name: 'right_shoulder' },
                { x: 0.3, y: 0.5, name: 'left_hand' },
                { x: 0.7, y: 0.5, name: 'right_hand' }
            ];
        }

        async transcribe({ videoElement, time }) {
            if (!this.isLoaded) await this.load();

            // Limit queue size
            if (this.transcriptionQueue.length > 5) {
                this.transcriptionQueue.shift(); // Remove oldest request
            }

            return new Promise((resolve) => {
                this.transcriptionQueue.push({ resolve, videoElement, time });
                this.processQueue().catch(console.error);
            });
        }

        async processQueue() {
            if (this.processingQueue) return;
            this.processingQueue = true;

            while (this.transcriptionQueue.length > 0) {
                const { resolve, videoElement, time } = this.transcriptionQueue[0];
                try {
                    const result = await this._doTranscribe({ videoElement, time });
                    resolve(result);
                } catch (error) {
                    console.error('Transcription error:', error);
                    resolve({ originalText: "Error transcribing", signGestures: [] });
                }
                this.transcriptionQueue.shift();
            }

            this.processingQueue = false;
        }

        async _doTranscribe({ videoElement, time }) {
            return new Promise((resolve, reject) => {
                let timeout;
                let hasResult = false;

                const cleanup = async () => {
                    clearTimeout(timeout);
                    if (this.recognition) {
                        await this.recognition.stop();
                    }
                };

                try {
                    this.recognition.onResult((event) => {
                        if (!event.results.length) return;
                        
                        const last = event.results[event.results.length - 1];
                        if (!last.isFinal) return;

                        const transcribedText = last[0].transcript || ''; // Ensure text is a string
                        console.log('Transcribed text:', transcribedText);

                        hasResult = true;
                        this.lastResult = transcribedText;
                        cleanup().then(async () => {
                            const gestures = await this.textToSignGestures(transcribedText);
                            resolve({
                                originalText: transcribedText,
                                signGestures: gestures
                            });
                        });
                    });

                    this.recognition.onError((error) => {
                        if (error.error === 'network') return;
                        
                        if (!hasResult) {
                            cleanup().then(() => {
                                resolve({
                                    originalText: "Listening...",
                                    signGestures: [{
                                        word: "listening",
                                        position: [0.5, 0.5],
                                        gesture: 'neutral'
                                    }]
                                });
                            });
                        }
                    });

                    timeout = setTimeout(() => {
                        if (!hasResult) {
                            cleanup().then(() => {
                                resolve({
                                    originalText: "Waiting for speech...",
                                    signGestures: [{
                                        word: "waiting",
                                        position: [0.5, 0.5],
                                        gesture: 'neutral'
                                    }]
                                });
                            });
                        }
                    }, 5000);

                    // Add error recovery
                    let startAttempts = 0;
                    const tryStart = async () => {
                        try {
                            await this.recognition.start();
                        } catch (error) {
                            if (startAttempts < 3) {
                                startAttempts++;
                                await new Promise(resolve => setTimeout(resolve, 500));
                                await tryStart();
                            } else {
                                throw error;
                            }
                        }
                    };

                    tryStart().catch(error => {
                        cleanup();
                        reject(error);
                    });
                } catch (error) {
                    cleanup().then(() => reject(error));
                }
            });
        }

        async stopRecognition() {
            this.transcriptionQueue = []; // Clear queue
            if (this.recognition) {
                await this.recognition.stop();
                this.transcriptionLock = false;
            }
        }

        generateGestureForWord(word) {
            if (!word || typeof word !== 'string') {
                return {
                    word: 'unknown',
                    gesture: 'neutral',
                    arms: {
                        left: { x: -20, y: 20 },
                        right: { x: 20, y: 20 }
                    },
                    height: 1,
                    shouldAnimate: false,
                    description: 'Unknown gesture'
                };
            }
        
            const gestureType = this.getGestureType(word);
            const leftArm = this.getArmPosition(word[0] || 'a', 'left');
            const rightArm = this.getArmPosition(word[word.length - 1] || 'a', 'right');
        
            return {
                word: word,
                gesture: gestureType,
                arms: {
                    left: leftArm,
                    right: rightArm
                },
                height: this.getGestureHeight(word.length),
                shouldAnimate: this.shouldAnimate(word),
                description: `Sign for "${word}"`
            };
        }

        getGestureType(word) {
            // Analyze word meaning/pattern for gesture type
            if (word.match(/^(hi|hello|hey)/)) return 'wave';
            if (word.match(/^(this|that|there|here)/)) return 'point';
            if (word.match(/^(i|me|my)/)) return 'self';
            if (word.match(/^(you|your)/)) return 'point-out';
            if (word.match(/^(we|our)/)) return 'circle';
            if (word.match(/^(how|what|why|when)/)) return 'question';
            if (word.match(/^(no|not|never)/)) return 'negative';
            if (word.match(/^(yes|ok|okay)/)) return 'affirmative';
            return 'expressive'; // Default to expressive gesture
        }

        getArmPosition(char, side) {
            // Generate arm positions based on phonetics
            const vowels = 'aeiou';
            const consonants = 'bcdfghjklmnpqrstvwxyz';
            
            const basePosition = side === 'left' ? -20 : 20;
            
            if (vowels.includes(char)) {
                return {
                    x: basePosition * 1.5,
                    y: -20 + (vowels.indexOf(char) * 8)
                };
            }
            
            if (consonants.includes(char)) {
                return {
                    x: basePosition,
                    y: -10 + (consonants.indexOf(char) * 2)
                };
            }
            
            return { x: basePosition, y: 0 };
        }

        getGestureHeight(wordLength) {
            // Adjust gesture height based on word length
            return Math.min(0.3 + (wordLength * 0.05), 0.8);
        }

        shouldAnimate(word) {
            // Determine if gesture should be animated
            return word.length > 4 || 
                   word.match(/^(wave|move|walk|run|jump|dance|sing|play|work)/) !== null;
        }

        async textToSignGestures(text) {
            if (!text || typeof text !== 'string') {
                const waitingGesture = this.generateGestureForWord("waiting");
                return [waitingGesture];
            }
        
            const words = text.toLowerCase()
                            .split(' ')
                            .filter(word => word.length > 0);
        
            // Process gestures synchronously to avoid Promise issues
            return words.map(word => {
                if (!this.gestureCache.has(word)) {
                    this.gestureCache.set(word, this.generateGestureForWord(word));
                }
                return this.gestureCache.get(word);
            });
        }
        
        async renderSignLanguage(canvas, gesturesData) {
            try {
                const gestures = Array.isArray(gesturesData) ? gesturesData : [gesturesData];
                if (!gestures.length) {
                    console.error('No gestures to render');
                    return;
                }
        
                console.log('Rendering gestures:', gestures);
                const ctx = canvas.getContext('2d');
                
                for (const gesture of gestures) {
                    const validGesture = this.normalizeGesture(gesture);
                    
                    // Clear canvas
                    ctx.fillStyle = 'black';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
        
                    // Draw gesture
                    await this.drawStickFigure(ctx, canvas.width / 2, canvas.height / 2, validGesture);
                    
                    // Add text
                    this.drawGestureText(ctx, validGesture, canvas.width, canvas.height);
                    
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
            } catch (error) {
                console.error('Render error:', error);
            }
        }
        
        normalizeGesture(gesture) {
            // Ensure gesture has all required properties
            return {
                word: gesture.word || 'unknown',
                gesture: gesture.gesture || 'neutral',
                arms: {
                    left: gesture.arms?.left || { x: -20, y: 20 },
                    right: gesture.arms?.right || { x: 20, y: 20 }
                },
                height: gesture.height || 1,
                shouldAnimate: gesture.shouldAnimate || false,
                description: gesture.description || `Sign for "${gesture.word || 'unknown'}"`
            };
        }
        
        drawStickFigure(ctx, x, y, gestureData) {
            const scale = 2;
            ctx.strokeStyle = 'white';
            ctx.lineWidth = 4;
        
            // Draw head
            ctx.beginPath();
            ctx.arc(x, y - 40 * scale, 20, 0, Math.PI * 2);
            ctx.stroke();
        
            // Draw body
            ctx.beginPath();
            ctx.moveTo(x, y - 20 * scale);
            ctx.lineTo(x, y + 20 * scale * (gestureData.height || 1));
            ctx.stroke();
        
            // Draw arms
            const normalizedArms = {
                left: gestureData.arms?.left || { x: -20, y: 20 },
                right: gestureData.arms?.right || { x: 20, y: 20 }
            };
        
            return gestureData.shouldAnimate ? 
                this.animateArms(ctx, x, y, normalizedArms, scale) :
                this.drawStaticArms(ctx, x, y, normalizedArms, scale);
        }

        async drawStickFigure(ctx, x, y, gestureData) {
            const scale = 2;
            ctx.strokeStyle = 'white';
            ctx.lineWidth = 4;

            // Draw head
            ctx.beginPath();
            ctx.arc(x, y - 40 * scale, 20, 0, Math.PI * 2);
            ctx.stroke();

            // Draw body
            ctx.beginPath();
            ctx.moveTo(x, y - 20 * scale);
            ctx.lineTo(x, y + 20 * scale * (gestureData.height || 1));
            ctx.stroke();

            // Draw arms
            if (gestureData.shouldAnimate) {
                await this.animateArms(ctx, x, y, gestureData.arms, scale);
            } else {
                this.drawStaticArms(ctx, x, y, gestureData.arms, scale);
            }
        }

        drawStaticArms(ctx, x, y, arms, scale) {
            if (!arms || !arms.left || !arms.right) {
                console.error('Invalid arm data:', arms);
                return;
            }

            ctx.beginPath();
            // Left arm
            ctx.moveTo(x - 20 * scale, y);
            ctx.lineTo(x + arms.left.x * scale, y + arms.left.y * scale);
            // Right arm
            ctx.moveTo(x + 20 * scale, y);
            ctx.lineTo(x + arms.right.x * scale, y + arms.right.y * scale);
            ctx.stroke();
        }

        async animateArms(ctx, x, y, arms, scale) {
            if (!arms || !arms.left || !arms.right) {
                console.error('Invalid arm data:', arms);
                return;
            }

            const frames = 30;
            for (let i = 0; i < frames; i++) {
                // Clear arms area only
                ctx.fillStyle = 'black';
                ctx.fillRect(x - 100, y - 50, 200, 100);

                const progress = (Math.sin(i / frames * Math.PI * 2) + 1) / 2;
                
                ctx.beginPath();
                // Animate left arm
                ctx.moveTo(x - 20 * scale, y);
                ctx.lineTo(
                    x + arms.left.x * scale,
                    y + (arms.left.y + progress * 10) * scale
                );
                // Animate right arm
                ctx.moveTo(x + 20 * scale, y);
                ctx.lineTo(
                    x + arms.right.x * scale,
                    y + (arms.right.y + progress * 10) * scale
                );
                ctx.stroke();

                await new Promise(resolve => setTimeout(resolve, 30));
            }
        }

        drawGestureText(ctx, gesture, width, height) {
            // Draw word
            ctx.fillStyle = 'white';
            ctx.font = 'bold 24px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(gesture.word.toUpperCase(), width / 2, height - 40);
            
            // Draw gesture type
            ctx.fillStyle = 'yellow';
            ctx.font = '16px Arial';
            ctx.fillText(gesture.description, width / 2, 30);
            
            // Draw debug info
            ctx.font = '12px Arial';
            ctx.fillText(`Type: ${gesture.gesture}`, width / 2, 50);
        }

        drawHead(ctx, x, y, gesture) {
            ctx.beginPath();
            ctx.arc(x, y, 20, 0, Math.PI * 2);
            ctx.stroke();
        }

        getPoseForGesture(gesture) {
            const poses = {
                'wave': [
                    { x: 0.5, y: 0.3 },
                    { x: 0.5, y: 0.4 },
                    { x: 0.3, y: 0.2 },
                    { x: 0.7, y: 0.5 },
                ],
                'point': [
                    { x: 0.5, y: 0.3 },
                    { x: 0.5, y: 0.4 },
                    { x: 0.3, y: 0.5 },
                    { x: 0.8, y: 0.4 },
                ],
                'neutral': [
                    { x: 0.5, y: 0.3 },
                    { x: 0.5, y: 0.4 },
                    { x: 0.3, y: 0.5 },
                    { x: 0.7, y: 0.5 },
                ]
            };
            return poses[gesture] || poses.neutral;
        }

        async drawAvatarWithPose(ctx, x, y, pose) {
            ctx.strokeStyle = 'white';
            ctx.lineWidth = 3;
            ctx.beginPath();
            
            for (let i = 0; i < pose.length - 1; i++) {
                const current = pose[i];
                const next = pose[i + 1];
                ctx.moveTo(x + current.x * 100, y + current.y * 100);
                ctx.lineTo(x + next.x * 100, y + next.y * 100);
            }
            
            ctx.stroke();

            ctx.fillStyle = 'red';
            pose.forEach(point => {
                ctx.beginPath();
                ctx.arc(x + point.x * 100, y + point.y * 100, 5, 0, Math.PI * 2);
                ctx.fill();
            });
        }
    }

    // Modify initialization to be more robust
    const initializeWithRetry = async (retries = 3) => {
        if (window.whisperModel?.isLoaded) return window.whisperModel;
        
        for (let i = 0; i < retries; i++) {
            try {
                const model = new VideoSignLanguageConverter();
                await model.load();
                
                if (!model.isLoaded) {
                    throw new Error('Model failed to load properly');
                }
                
                window.whisperModel = model;
                document.dispatchEvent(new CustomEvent('whisper-model-ready'));
                console.log('Whisper model initialized successfully');
                return model;
            } catch (error) {
                console.error(`Init attempt ${i + 1} failed:`, error);
                if (i === retries - 1) throw error;
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
    };

    // Only initialize once both document and speech recognition are ready
    const initialize = () => {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                document.addEventListener('speech-recognizer-loaded', () => {
                    initializeWithRetry().catch(console.error);
                });
            });
        } else {
            document.addEventListener('speech-recognizer-loaded', () => {
                initializeWithRetry().catch(console.error);
            });
            
            // Try immediate initialization if speech recognition is already loaded
            if (window.speechRecognizerLoaded) {
                initializeWithRetry().catch(console.error);
            }
        }
    };

    initialize();
})();
