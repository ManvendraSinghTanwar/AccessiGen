function initializeElements() {
  const previewContainer = document.createElement('div');
  previewContainer.className = 'camera-preview-container';
  document.body.appendChild(previewContainer);

  const videoElement = document.createElement('video');
  videoElement.className = 'camera-feed';
  videoElement.style.display = 'block';
  previewContainer.appendChild(videoElement);

  const canvasElement = document.createElement('canvas');
  canvasElement.className = 'landmark-overlay';
  canvasElement.width = 640;
  canvasElement.height = 480;
  previewContainer.appendChild(canvasElement);

  const cursorElement = document.createElement('div');
  cursorElement.className = 'virtual-cursor';
  document.body.appendChild(cursorElement);

  return { videoElement, cursorElement, canvasElement };
}

function handleMouseControl(landmarks, position, cursorElement) {
  const indexFinger = landmarks[8];
  const thumb = landmarks[4];

  // Map coordinates to screen
  const x = (1 - indexFinger.x) * window.innerWidth;
  const y = indexFinger.y * window.innerHeight;

  // Calculate movement
  const dx = x - position.lastX;
  const dy = y - position.lastY;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // Update position with sensitivity
  const adaptiveSensitivity = position.sensitivity * (1 + distance * 0.01);
  position.lastX += dx * adaptiveSensitivity;
  position.lastY += dy * adaptiveSensitivity;

  // Update cursor
  cursorElement.style.left = `${position.lastX}px`;
  cursorElement.style.top = `${position.lastY}px`;

  return { x, y, pinchDistance: Math.hypot(thumb.x - indexFinger.x, thumb.y - indexFinger.y) };
}

function performClick(x, y) {
  const element = document.elementFromPoint(x, y);
  if (!element) return;

  ['mousedown', 'mouseup', 'click'].forEach(eventType => {
    element.dispatchEvent(new MouseEvent(eventType, {
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y
    }));
  });
}

// Make functions globally available
window.initializeElements = function() {
  const previewContainer = document.createElement('div');
  previewContainer.className = 'camera-preview-container';
  document.body.appendChild(previewContainer);

  const videoElement = document.createElement('video');
  videoElement.className = 'camera-feed';
  videoElement.style.display = 'block';
  previewContainer.appendChild(videoElement);

  const canvasElement = document.createElement('canvas');
  canvasElement.className = 'landmark-overlay';
  canvasElement.width = 640;
  canvasElement.height = 480;
  previewContainer.appendChild(canvasElement);

  const cursorElement = document.createElement('div');
  cursorElement.className = 'virtual-cursor';
  document.body.appendChild(cursorElement);

  return { videoElement, cursorElement, canvasElement };
};

window.handleMouseControl = function(landmarks, position, cursorElement) {
  const indexFinger = landmarks[8];
  const thumb = landmarks[4];

  // Map coordinates to screen
  const x = (1 - indexFinger.x) * window.innerWidth;
  const y = indexFinger.y * window.innerHeight;

  // Calculate movement
  const dx = x - position.lastX;
  const dy = y - position.lastY;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // Update position with sensitivity
  const adaptiveSensitivity = position.sensitivity * (1 + distance * 0.01);
  position.lastX += dx * adaptiveSensitivity;
  position.lastY += dy * adaptiveSensitivity;

  // Update cursor
  cursorElement.style.left = `${position.lastX}px`;
  cursorElement.style.top = `${position.lastY}px`;

  return { x, y, pinchDistance: Math.hypot(thumb.x - indexFinger.x, thumb.y - indexFinger.y) };
};

window.performClick = function(x, y) {
  const element = document.elementFromPoint(x, y);
  if (!element) return;

  ['mousedown', 'mouseup', 'click'].forEach(eventType => {
    element.dispatchEvent(new MouseEvent(eventType, {
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y
    }));
  });
};
