let cursorElement = null;
let lastClickTime = 0;
const CLICK_DELAY = 300;
let isInitialized = false;

// Position state management
const position = {
  lastX: window.innerWidth / 2,
  lastY: window.innerHeight / 2,
  sensitivity: 0.3,
  clickThreshold: 0.02
};

let htracker = null;
let trackingMode = 'combined'; // 'eye', 'head', or 'combined'

// Message Listener for Chrome Extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'initializeTracking':
      if (!isInitialized) {
        initialize().then(() => {
          isInitialized = true;
          sendResponse({ success: true });
        }).catch(error => {
          console.error('Initialization failed:', error);
          sendResponse({ success: false, error: error.message });
        });
      } else {
        sendResponse({ success: true });
      }
      return true;
    
    case 'togglePreview':
      document.querySelector('.camera-preview-container').style.display = request.show ? 'block' : 'none';
      sendResponse({ success: true });
      break;
    
    case 'updateSensitivity':
      position.sensitivity = request.value * 0.1; // Convert 1-10 to 0.1-1.0
      sendResponse({ success: true });
      break;
    
    case 'toggleTracking':
      if (request.enabled) {
        webgazer.resume();
      } else {
        webgazer.pause();
      }
      sendResponse({ success: true });
      break;
    
    case 'setTrackingMode':
      trackingMode = request.mode;
      if (trackingMode === 'head') {
        webgazer.pause();
        htracker.start();
      } else if (trackingMode === 'eye') {
        htracker.stop();
        webgazer.resume();
      } else {
        webgazer.resume();
        htracker.start();
      }
      sendResponse({ success: true });
      break;
  }
  return true;
});

// Initialize elements
function initializeElements() {
  cursorElement = document.createElement('div');

  cursorElement.className = 'cursor-tracker';
  cursorElement.style.position = 'absolute';
  cursorElement.style.width = '20px';
  cursorElement.style.height = '20px';
  cursorElement.style.backgroundColor = 'red';
  cursorElement.style.borderRadius = '50%';
  cursorElement.style.pointerEvents = 'none';

  document.body.appendChild(cursorElement);
  
  return { cursorElement };
}

// Initialize Eye Tracking
async function initializeEyeTracking() {
  cursorElement = initializeElements().cursorElement;

  // Initialize WebGazer
  await webgazer.setRegression('ridge')
    .setTracker('TFFacemesh')
    .setGazeListener((data, timestamp) => {
      if (data == null) return;
      
      // Update cursor position with eye gaze data
      const dx = data.x - position.lastX;
      const dy = data.y - position.lastY;
      
      position.lastX += dx * position.sensitivity;
      position.lastY += dy * position.sensitivity;
      
      cursorElement.style.left = `${position.lastX}px`;
      cursorElement.style.top = `${position.lastY}px`;
      
      // Detect fixation for clicking
      detectFixation(dx, dy);
    })
    .begin();

  // Show camera feed in preview
  const videoFeed = webgazer.getVideoElementCanvas();
  const container = document.querySelector('.camera-preview-container');
  container.style.display = 'block';
  container.style.visibility = 'visible';
  container.appendChild(videoFeed);
}

// Initialize Head Tracking
async function initializeHeadTracking() {
  const videoInput = document.createElement('video');
  videoInput.id = 'headtracking-video';
  videoInput.style.display = 'none';
  document.body.appendChild(videoInput);

  htracker = new headtrackr.Tracker({
    calcAngles: true,
    ui: false,
    headPosition: true
  });

  htracker.init(videoInput);
  htracker.start();

  // Handle head movements
  document.addEventListener('headtrackingEvent', (e) => {
    if (trackingMode === 'head' || trackingMode === 'combined') {
      const x = (e.x * 2 + window.innerWidth/2) * position.sensitivity;
      const y = (e.y * 2 + window.innerHeight/2) * position.sensitivity;
      
      if (trackingMode === 'head') {
        updateCursorPosition(x, y);
      } else {
        // Combined mode - average with eye position
        updateCursorPosition((x + position.lastX)/2, (y + position.lastY)/2);
      }

      // Detect head nod for clicking
      if (Math.abs(e.z - lastZ) > 10) {
        performClick(position.lastX, position.lastY);
      }
      lastZ = e.z;
    }
  });
}

function updateCursorPosition(x, y) {
  position.lastX = x;
  position.lastY = y;
  cursorElement.style.left = `${x}px`;
  cursorElement.style.top = `${y}px`;
}

// Initialize
async function initialize() {
  if (isInitialized) return;

  try {
    // Initialize UI elements
    const elements = initializeElements();
    cursorElement = elements.cursorElement;

    // Initialize both tracking systems
    await Promise.all([
      initializeHeadTracking(),
      initializeEyeTracking()
    ]);

    const container = document.querySelector('.camera-preview-container');
    container.style.display = 'block';
    container.style.visibility = 'visible';

    isInitialized = true;
  } catch (error) {
    console.error('Initialization failed:', error);
    throw error;
  }
}

// Detect Fixation for Clicking
function detectFixation(dx, dy) {
  const movement = Math.sqrt(dx * dx + dy * dy);
  const fixationThreshold = 0.01;
  
  if (movement < fixationThreshold) {
    const now = Date.now();
    if (now - lastClickTime > CLICK_DELAY) {
      performClick(position.lastX, position.lastY);
      lastClickTime = now;
      cursorElement.classList.add('clicking');
      setTimeout(() => cursorElement.classList.remove('clicking'), 200);
    }
  }
}

// Simulate Click at Position
function performClick(x, y) {
  const clickEvent = new MouseEvent('click', {
    bubbles: true,
    cancelable: true,
    view: window,
    clientX: x,
    clientY: y
  });
  document.elementFromPoint(x, y)?.dispatchEvent(clickEvent);
}

function handleHeadControl(face, position, cursorElement) {
  // Map head position to screen with improved sensitivity
  const targetX = (face.x * window.innerWidth * 2) + (window.innerWidth / 2);
  const targetY = (face.y * window.innerHeight * 1.5) + (window.innerHeight / 2);
  
  // Smooth movement with dynamic sensitivity
  const dx = targetX - position.lastX;
  const dy = targetY - position.lastY;
  
  // Apply non-linear acceleration for more precise control
  const distance = Math.sqrt(dx * dx + dy * dy);
  const acceleration = Math.min(distance * 0.01, 1.0);
  
  position.lastX += dx * position.sensitivity * acceleration;
  position.lastY += dy * position.sensitivity * acceleration;
  
  // Keep cursor within screen bounds
  position.lastX = Math.max(0, Math.min(window.innerWidth, position.lastX));
  position.lastY = Math.max(0, Math.min(window.innerHeight, position.lastY));
  
  // Update cursor position with smoothing
  cursorElement.style.left = `${position.lastX}px`;
  cursorElement.style.top = `${position.lastY}px`;

  // Add visual feedback for clicks
  document.addEventListener('click', () => {
    cursorElement.classList.add('clicking');
    setTimeout(() => cursorElement.classList.remove('clicking'), 200);
  });
}
