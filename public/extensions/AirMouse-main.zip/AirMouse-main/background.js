chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    enableTracking: true, // Enable tracking by default
    showPreview: true,
    sensitivity: 5,
    initialized: false
  });
});

// Modify tab tracking
let initializedTabs = new Set();

async function injectScripts(tabId) {
  try {
    // Inject camera access code directly into the page
    await chrome.scripting.executeScript({
      target: { tabId },
      function: () => {
        // This runs in the page context
        if (!document.querySelector('#air-mouse-camera')) {
          const video = document.createElement('video');
          video.id = 'air-mouse-camera';
          video.autoplay = true;
          video.style.cssText = 'position:fixed;bottom:20px;right:20px;width:320px;height:240px;z-index:9999;';
          document.body.appendChild(video);
          
          navigator.mediaDevices.getUserMedia({ video: true })
            .then(stream => {
              video.srcObject = stream;
            })
            .catch(console.error);
        }
      }
    });

    // Check if the tab is accessible first
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || tab.url.startsWith('chrome://')) {
      console.log('Cannot inject into chrome:// pages');
      return false;
    }

    // Check if URL matches our patterns
    const validUrlPattern = /^(http|https):\/\//i;
    if (!validUrlPattern.test(tab.url)) {
      console.log('URL not supported:', tab.url);
      return false;
    }

    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });

    // Wait a bit to ensure content script is loaded
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Initialize the tab
    await chrome.tabs.sendMessage(tabId, { type: 'initializeTracking' });
    
    initializedTabs.add(tabId);
    return true;
  } catch (error) {
    console.error('Script injection failed:', error);
    return false;
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'initializeTab') {
    injectScripts(sender.tab.id).then(success => {
      sendResponse({ success });
    });
    return true;
  }
  if (request.type === 'getInitStatus') {
    sendResponse({ initialized: initializedTabs.has(sender.tab.id) });
    return true;
  }
  if (request.type === 'getSettings') {
    chrome.storage.local.get(['enableTracking', 'sensitivity'], (result) => {
      sendResponse(result);
    });
    return true;
  }
  if (request.type === 'checkInit') {
    sendResponse({ initialized: initializedTabs.has(request.tabId) });
    return true;
  }
});

// Update tab handling with URL checks
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && !tab.url.startsWith('chrome://')) {
    injectScripts(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  initializedTabs.delete(tabId);
});

chrome.action.onClicked.addListener(async (tab) => {
  await injectScripts(tab.id);
});

// Ensure tab is initialized when activated
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  if (!initializedTabs.has(activeInfo.tabId)) {
    await injectScripts(activeInfo.tabId);
  }
});
