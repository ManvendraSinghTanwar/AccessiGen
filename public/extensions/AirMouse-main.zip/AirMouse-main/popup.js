document.addEventListener('DOMContentLoaded', async () => {
  const showPreview = document.getElementById('showPreview');
  const enableTracking = document.getElementById('enableTracking');
  const sensitivity = document.getElementById('sensitivity');
  const enableTyping = document.getElementById('enableTyping');
  const statusElement = document.createElement('div');
  statusElement.className = 'status';
  document.body.appendChild(statusElement);

  const trackingMode = document.getElementById('trackingMode');

  function showStatus(message, isError = false) {
    statusElement.textContent = message;
    statusElement.className = `status ${isError ? 'error' : 'success'}`;
    setTimeout(() => statusElement.textContent = '', 3000);
  }

  async function initializeTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error('No active tab found');

      // First check if already initialized
      const initStatus = await chrome.runtime.sendMessage({ 
        type: 'checkInit',
        tabId: tab.id 
      });

      if (initStatus.initialized) return true;

      // Initialize if needed
      const success = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });

      if (!success) throw new Error('Script injection failed');

      // Wait for content script to initialize
      await new Promise(resolve => setTimeout(resolve, 500));

      // Verify initialization
      const response = await chrome.tabs.sendMessage(tab.id, { 
        type: 'initializeTracking' 
      });

      return response?.success ?? false;
    } catch (error) {
      console.error('Tab initialization failed:', error);
      return false;
    }
  }

  async function sendMessageToActiveTab(message) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error('No active tab found');

      // Try to initialize if needed
      if (!await initializeTab()) {
        showStatus('Failed to initialize. Try refreshing the page.', true);
        return;
      }

      const response = await chrome.tabs.sendMessage(tab.id, message);
      if (!response?.success) {
        throw new Error('Message failed');
      }
    } catch (error) {
      showStatus('Communication error. Please refresh the page.', true);
      console.error('Message sending failed:', error);
    }
  }

  async function checkInitialization() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return false;
    
    try {
      await chrome.tabs.sendMessage(tab.id, { type: 'initializeTracking' });
      showStatus('Hand tracking activated', false);
      return true;
    } catch (error) {
      showStatus('Please refresh the page to activate hand tracking', true);
      return false;
    }
  }

  // Add retry button
  const retryButton = document.createElement('button');
  retryButton.textContent = 'Retry Activation';
  retryButton.style.display = 'none';
  document.body.appendChild(retryButton);

  retryButton.addEventListener('click', async () => {
    const success = await checkInitialization();
    retryButton.style.display = success ? 'none' : 'block';
  });

  // Initialize on popup open
  await initializeTab();

  // Check initialization on popup open
  const success = await checkInitialization();
  retryButton.style.display = success ? 'none' : 'block';

  // Load saved settings
  chrome.storage.local.get(['showPreview', 'enableTracking', 'sensitivity', 'enableTyping'], (result) => {
    showPreview.checked = result.showPreview ?? true;
    enableTracking.checked = result.enableTracking ?? false;
    sensitivity.value = result.sensitivity ?? 5;
    enableTyping.checked = result.enableTyping ?? false;
    
    // Apply initial settings
    sendMessageToActiveTab({
      type: 'togglePreview',
      show: showPreview.checked
    });
    sendMessageToActiveTab({
      type: 'toggleTracking',
      enabled: enableTracking.checked
    });
    sendMessageToActiveTab({
      type: 'toggleTyping',
      enabled: enableTyping.checked
    });
  });

  showPreview.addEventListener('change', () => {
    sendMessageToActiveTab({
      type: 'togglePreview',
      show: showPreview.checked
    });
    chrome.storage.local.set({ showPreview: showPreview.checked });
  });

  enableTracking.addEventListener('change', () => {
    sendMessageToActiveTab({
      type: 'toggleTracking',
      enabled: enableTracking.checked
    });
    chrome.storage.local.set({ enableTracking: enableTracking.checked });
  });

  sensitivity.addEventListener('input', () => {
    sendMessageToActiveTab({
      type: 'updateSensitivity',
      value: Number(sensitivity.value)
    });
    chrome.storage.local.set({ sensitivity: Number(sensitivity.value) });
  });

  enableTyping.addEventListener('change', () => {
    sendMessageToActiveTab({
      type: 'toggleTyping',
      enabled: enableTyping.checked
    });
    chrome.storage.local.set({ enableTyping: enableTyping.checked });
  });

  trackingMode.addEventListener('change', () => {
    sendMessageToActiveTab({
      type: 'setTrackingMode',
      mode: trackingMode.value
    });
    chrome.storage.local.set({ trackingMode: trackingMode.value });
  });

  // Load tracking mode preference
  chrome.storage.local.get('trackingMode', (result) => {
    trackingMode.value = result.trackingMode || 'hand';
    sendMessageToActiveTab({
      type: 'setTrackingMode',
      mode: trackingMode.value
    });
  });
});
