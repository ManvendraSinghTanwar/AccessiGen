window.loadMediaPipe = async function() {
  const CDN_BASE = 'https://cdn.jsdelivr.net/npm/@mediapipe';
  const HANDS_VERSION = '0.4.1646424915';
  
  const dependencies = [
    `${CDN_BASE}/hands@${HANDS_VERSION}/hands.js`,
    `${CDN_BASE}/camera_utils@${HANDS_VERSION}/camera_utils.js`,
    `${CDN_BASE}/drawing_utils@${HANDS_VERSION}/drawing_utils.js`,
    `${CDN_BASE}/face_mesh@${HANDS_VERSION}/face_mesh.js`
  ];

  for (const src of dependencies) {
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = src;
      script.crossOrigin = 'anonymous';
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  // Wait for MediaPipe to be fully initialized
  await new Promise(resolve => setTimeout(resolve, 2000));

  if (!window.Hands) {
    throw new Error('MediaPipe Hands failed to initialize');
  }

  return {
    Hands: window.Hands,
    FaceMesh: window.FaceMesh,
    Camera: window.Camera,
    drawConnectors: window.drawConnectors,
    drawLandmarks: window.drawLandmarks,
    HAND_CONNECTIONS: window.HAND_CONNECTIONS,
    FACEMESH_FACE_OVAL: window.FACEMESH_FACE_OVAL
  };
};
